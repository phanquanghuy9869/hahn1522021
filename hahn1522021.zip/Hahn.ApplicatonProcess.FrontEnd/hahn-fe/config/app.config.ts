const AppConfig = {
    baseApiUrl: 'http://localhost:5000/api',
    applicantUrl: {
        add: 'applicant'
    },
    countryUrl: {
        validate: 'country/validate'
    }
}

export default AppConfig;