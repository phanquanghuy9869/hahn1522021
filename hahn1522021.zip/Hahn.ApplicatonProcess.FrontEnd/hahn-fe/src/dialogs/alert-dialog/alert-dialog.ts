import { inject } from 'aurelia-framework';
import { DialogController } from 'aurelia-dialog';

@inject(DialogController)
export class AlertDialog {
    header: string;
    messages: any[] = [];

    constructor(public controller) {
        this.controller.settings.centerHorizontalOnly = true;
    }
    activate(model) {
        this.messages = model.messages;
        this.header = model.header;
    }
}