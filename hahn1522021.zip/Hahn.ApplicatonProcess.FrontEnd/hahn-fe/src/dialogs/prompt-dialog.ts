import {inject} from 'aurelia-framework';
import {DialogController} from 'aurelia-dialog';

@inject(DialogController)
export class PromptDialog {
   answer = null; 
   message = '';

   constructor(public controller) {
      this.controller.settings.centerHorizontalOnly = true;
   }
   activate(message) {
      this.message = message;
   }
}