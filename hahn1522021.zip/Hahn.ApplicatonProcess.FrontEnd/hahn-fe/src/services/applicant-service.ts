import { HttpClient, json } from 'aurelia-fetch-client';
import { inject, NewInstance } from 'aurelia-framework';
import AppConfig from '../../config/app.config';

@inject(HttpClient)
export class ApplicantService {

    public constructor(private http : HttpClient) {
    }

    public async addApplication(applicant) {
        const result = await this.http.fetch(`${AppConfig.baseApiUrl}/${AppConfig.applicantUrl.add}`, {
            method: 'post',
            body: JSON.stringify(applicant),
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        });      
        return await result.json();
    }
}