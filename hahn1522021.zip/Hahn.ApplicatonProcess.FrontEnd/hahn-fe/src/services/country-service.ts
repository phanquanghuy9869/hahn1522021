import { HttpClient, json } from 'aurelia-fetch-client';
import { inject, NewInstance } from 'aurelia-framework';
import AppConfig from '../../config/app.config';

@inject(HttpClient)
export class CountryService {
    
    public constructor(private http : HttpClient) {
    }

    public async validateCountry(country) {
        if (country == null || country.trim().length == 0) {
            return false;
        }
        const result = await this.http.fetch(`${AppConfig.baseApiUrl}/${AppConfig.countryUrl.validate}/${country}`, {
            method: 'get',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        });
        return await result.json();
    }
}