
import {RouterConfiguration, Router} from 'aurelia-router';
import { inject, PLATFORM } from 'aurelia-framework';
  
@inject(RouterConfiguration, Router)
export class App {
  router: Router;

  configureRouter(config: RouterConfiguration, router: Router): void {
    this.router = router;
    config.title = 'Aurelia';
    config.map([
      { route: ['', 'home'],       name: 'home',       moduleId: PLATFORM.moduleName('components/applicant/applicant') },
      { route: 'success',       name: 'success',       moduleId: PLATFORM.moduleName('components/operation/operation-success') },
    ]);
  }
}
