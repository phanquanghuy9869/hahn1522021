export class OperationSuccess {
    
}