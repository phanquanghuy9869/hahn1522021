import { inject, NewInstance } from 'aurelia-framework';
import { ValidationControllerFactory, ValidationRules, ValidationController, validateTrigger, Validator, FluentEnsure } from 'aurelia-validation';
import { BootstrapFormRenderer } from '../../custom-renderers/bootstrap-form-renderer';
import { DialogService } from 'aurelia-dialog';
import { PromptDialog } from '../../dialogs/prompt-dialog';
import { ApplicantService } from 'services/applicant-service';
import { CountryService } from 'services/country-service';
import { I18N } from 'aurelia-i18n';
import { AlertDialog } from '../../dialogs/alert-dialog/alert-dialog';
import { Router } from 'aurelia-router';
// import 'bootstrap';

interface ApplicantModel {
  id?: string;
  name?: string;
  familyName?: string;
  address?: string;
  countryOfOrigin?: string;
  emailAddress?: string;
  age?: number;
  hired?: boolean;
  title?: string;
}

// https://aurelia.io/docs/plugins/validation#validation-controller
@inject(Validator, ValidationControllerFactory, DialogService, ApplicantService,CountryService, I18N, Router)
export class Applicant {
  // static inject = [DialogService];
  controller: ValidationController;
  applicant: ApplicantModel = {};
  canSave = false;
  boostrapFormRenderer: BootstrapFormRenderer;
  rule: FluentEnsure<ApplicantModel>;

  constructor(private _validator: Validator, private _controllerFactory, private _dialogService: DialogService
    , private _applicantService: ApplicantService, private _countryService : CountryService,
    private _i18n: I18N, private _router: Router) {
    this.controller = _controllerFactory.createForCurrentScope();

    ValidationRules.customRule(
      'validCountry', 
      async (value, object) => {
        try {
          const isValid = await _countryService.validateCountry(value);
          return isValid;
        } catch (error) {
          return false;
        }
      },
      this._i18n.tr('message.invalidCountry')
    )

    this.rule = ValidationRules
      .ensure((a: ApplicantModel) => a.emailAddress).email().required()
      .ensure((a: ApplicantModel) => a.name).required().minLength(5)
      .ensure((a: ApplicantModel) => a.familyName).required().minLength(5)
      .ensure((a: ApplicantModel) => a.address).required().minLength(10)
      .ensure((a: ApplicantModel) => a.countryOfOrigin).required().satisfiesRule('validCountry')
      .ensure((a: ApplicantModel) => a.age).required().min(20).max(60)
      .on(this.applicant);

    this.boostrapFormRenderer = new BootstrapFormRenderer();
    this.controller.addRenderer(this.boostrapFormRenderer);
    this.controller.validateTrigger = validateTrigger.focusout;
    this.controller.subscribe(event => this.validate());
  }

  public async submit() {
    try {
      this.applicant.age = parseInt(this.applicant.age.toString());
      const response = await this._applicantService.addApplication(this.applicant);
      this._router.navigate("success");
    } catch (error) {
      const mes = [error.message];
      this.alertMessages(this._i18n.tr('message.error'), mes);
    }
  }

  public reset() {
    this._dialogService.open({ viewModel: PromptDialog, model: this._i18n.tr('message.resetAllData'), lock: false }).whenClosed(response => {
      if (!response.wasCancelled) {
        this.resetApplicantData();
      }
    });
  }

  public alertMessages(header: string, messages: string[]) {
    this._dialogService.open({ viewModel: AlertDialog, model: { header: header, messages: messages }, lock: false });
  }

  get isUserHasTyped() {
    const isNotEmptyData = !this.isEmptyApplicant();
    return isNotEmptyData;
  }

  private resetApplicantData() {
    this.applicant.emailAddress = '';
    this.applicant.name = '';
    this.applicant.familyName = '';
    this.applicant.address = '';
    this.applicant.countryOfOrigin = '';
    this.applicant.age = null;
    this.applicant.hired = false;
  }

  private isNullOrEmpty(s) {
    return (s == null || s === '');
  }

  private isEmptyApplicant() {
    return this.isNullOrEmpty(this.applicant.name) && this.isNullOrEmpty(this.applicant.familyName) && this.isNullOrEmpty(this.applicant.address) &&
      this.isNullOrEmpty(this.applicant.countryOfOrigin) && this.isNullOrEmpty(this.applicant.emailAddress) && (this.applicant.age == null || this.applicant.age == 0)
      && (this.applicant.hired != true);
  }

  private validate() {
    this._validator.validateObject(this.applicant)
      .then(results => this.canSave = results.every(result => result.valid));
  }
}

