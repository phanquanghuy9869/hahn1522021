﻿using FluentValidation;
using Hahn.ApplicatonProcess.December2020.Core.DTO;
using Hahn.ApplicatonProcess.December2020.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.December2020.Web.MiddleWare
{
    public class FluentValidator : AbstractValidator<ApplicantDto>
    {
        private readonly ICountryService _countryService;

        public FluentValidator(ICountryService countryService)
        {
            this._countryService = countryService;

            RuleFor(c => c.Name).MinimumLength(5);
            RuleFor(c => c.FamilyName).MinimumLength(5);
            RuleFor(c => c.Address).MinimumLength(10);
            RuleFor(c => c.EMailAddress).NotEmpty().EmailAddress();
            RuleFor(c => c.Age).InclusiveBetween(20, 60);
            RuleFor(c => c.Hired).NotNull();
            RuleFor(c => c.CountryOfOrigin).MustAsync(ValidateCountry).WithMessage("This 'CountryOfOrigin' is not a valid country");
        }

        public async Task<bool> ValidateCountry(string countryOfOrigin, CancellationToken cancellToken)
        {
            return await this._countryService.ValidateCountry(countryOfOrigin);
        }
    }
}
