﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Net;

namespace Hahn.ApplicatonProcess.December2020.Web.MiddleWare
{
    public class AppExceptionHandler
    {
        private static readonly ILogger _log = Serilog.Log.ForContext<AppExceptionHandler>();

        public static void Handle(IApplicationBuilder a)
        {
            a.Run(async context =>
            {
                var exceptionHandlerPathFeature = context.Features.Get<IExceptionHandlerPathFeature>();
                var exception = exceptionHandlerPathFeature.Error;
                _log.Error(exception, "Unhandle exception at {time}", DateTime.UtcNow.ToLongDateString());
                var code = HttpStatusCode.InternalServerError;
                var result = JsonConvert.SerializeObject(new { IsSuccess = false, Status = (int)code, Message = new string[] { exception.Message } });
                context.Response.ContentType = "application/json";
                await context.Response.WriteAsync(result);
            });
        }
    }
}
