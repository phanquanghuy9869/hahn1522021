﻿using AutoMapper;
using Hahn.ApplicatonProcess.December2020.Core.DomainModels;
using Hahn.ApplicatonProcess.December2020.Core.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.December2020.Web.AutoMapperProfile
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            // Add as many of these lines as you need to map your objects
            CreateMap<Applicant, ApplicantDto>();
            CreateMap<ApplicantDto, Applicant>();
        }
    }
}
