﻿using AutoMapper;
using Hahn.ApplicatonProcess.December2020.Core.DomainModels;
using Hahn.ApplicatonProcess.December2020.Core.DTO;
using Hahn.ApplicatonProcess.December2020.Core.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.December2020.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ApplicantController : ControllerBase
    {
        private readonly IApplicantService _applicantService;
        private readonly ILogger<ApplicantController> _logger;
        private readonly IMapper _mapper;

        public ApplicantController(IApplicantService applicantService, ILogger<ApplicantController> logger, IMapper mapper)
        {
            this._applicantService = applicantService;
            this._logger = logger;
            this._mapper = mapper;
        }

        /// <summary>
        /// Get an Applicant by id
        /// </summary>
        /// <param name="id"></param>
        /// <returns>Return the Applicant finded by id</returns>
        // GET api/<ValuesController>/1
        [HttpGet("{id}", Name = "Get")]
        [ProducesResponseType(200)]
        [ProducesResponseType(404)]
        public async Task<ActionResult> Get(int id)
        {
            _logger.LogInformation("Getting Applicant with Id = {Id} at {RequestTime}", id, DateTime.Now);
            var result = await this._applicantService.GetAsync(id);
            if (result == null)
            { 
                _logger.LogWarning("Getting Applicant with Id = {Id} NOT FOUND at {RequestTime}", id, DateTime.Now);
                return NotFound();
            }
            return Ok(result);
        }

        /// <summary>
        /// Create an Applicant
        /// </summary>
        /// <remarks>
        /// Sample request: 
        /// 
        /// {
        ///	"Name": "Phan Quang Huy",
        ///	"FamilyName": "Huy Phan",
        ///	"Address": "Ha Noi/Viet Nam",
        ///	"CountryOfOrigin": "aruba",
        ///	"EmailAddress": "phanquanghuy9869@gmail.com",
        ///	"Age": 31,
        ///	"Hired": true
        /// }
        /// </remarks>
        /// <param name="applicantDTO"></param>
        /// <returns> Return the created object </returns>
        // POST api/<ValuesController>
        [HttpPost]
        [ProducesResponseType(201)]
        [ProducesResponseType(400)]
        public async Task<ActionResult> Post([FromBody] ApplicantDto applicantDTO)
        {
            _logger.LogInformation("Add applicant at {RequestTime}", DateTime.Now);
            var applicant = await this._applicantService.AddAsync(_mapper.Map<Applicant>(applicantDTO));
            return CreatedAtRoute("Get", new { Id = applicant.Id }, applicant);
        }

        /// <summary>
        /// Update an Applicant
        /// </summary>
        /// <remarks>
        /// Sample request: 
        /// 
        /// {
        ///	"ID": 1,
        ///	"Name": "Phan Quang Huy modifed",
        ///	"FamilyName": "Huy Phan",
        ///	"Address": "Ha Noi/Viet Nam",
        ///	"CountryOfOrigin": "aruba",
        ///	"EmailAddress": "phanquanghuy9869@gmail.com",
        ///	"Age": 31,
        ///	"Hired": true
        /// }
        /// </remarks>
        /// <param name="id"></param>
        /// <param name="applicantDTO"></param>
        /// <returns></returns>
        // PUT api/<ValuesController>/5
        [HttpPut("{id}")]
        [ProducesResponseType(200)]
        [ProducesResponseType(404)]
        [ProducesResponseType(400)]
        public async Task<ActionResult> Put(int id, [FromBody] ApplicantDto applicantDTO)
        {
            _logger.LogInformation("Update Applicant with Id = {Id} at {RequestTime}", id, DateTime.Now);
            if (id != applicantDTO.Id)
            {
                //return BadRequest(new RespondData { IsSuccess = false, Status = 404 });
                return BadRequest();
            }

            var existed = await this._applicantService.IsExisted(id);
            if (!existed)
            {
                _logger.LogWarning("Put Applicant with Id = {Id} NOT FOUND at {RequestTime}", id, DateTime.Now);
                return NotFound();
            }

            await this._applicantService.UpdateAsync(_mapper.Map<Applicant>(applicantDTO));
            return Ok();
        }

        /// <summary>
        /// Delete an applicant
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // DELETE api/<ValuesController>/5
        [HttpDelete("{id}")]
        [ProducesResponseType(200)]
        [ProducesResponseType(404)]
        public async Task<ActionResult> Delete(int id)
        {
            _logger.LogInformation("Delete Applicant with Id = {Id} at {RequestTime}", id, DateTime.Now);
            var existed = await this._applicantService.IsExisted(id);
            if (!existed)
            {
                _logger.LogWarning("Delete Applicant with Id = {Id} NOT FOUND at {RequestTime}", id, DateTime.Now);
                return NotFound();
            }
            await this._applicantService.DeleteByIdAsync(id);

            return Ok();
        }
    }

}
