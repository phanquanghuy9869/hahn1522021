﻿using Hahn.ApplicatonProcess.December2020.Core.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.December2020.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CountryController : ControllerBase
    {
        private readonly ICountryService _countryService;

        public CountryController(ICountryService countryService)
        {
            _countryService = countryService;
        }

        [HttpGet("validate/{country}")]
        public async Task<IActionResult> ValidateCountry(string country)
        {
            var isValid = await _countryService.ValidateCountry(country);
            return Ok(isValid);
        }
    }
}
