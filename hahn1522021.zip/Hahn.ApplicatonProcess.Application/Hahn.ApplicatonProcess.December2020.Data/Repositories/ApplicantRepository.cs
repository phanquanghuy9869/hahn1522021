﻿using Hahn.ApplicatonProcess.December2020.Core.DomainModels;
using Hahn.ApplicatonProcess.December2020.Core.Interfaces;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.December2020.Data.Repositories
{
    public class ApplicantRepository : EFGenericRepository<Applicant>, IApplicantRepository
    {
        public ApplicantRepository(DbContext context) : base(context)
        {
        }

        public async Task DeleteByIdAsync(int id)
        {
            var applicant = new Applicant { Id = id };
            _dbSet.Attach(applicant);
            _dbSet.Remove(applicant);
            await _context.SaveChangesAsync();
        }
    }
}
