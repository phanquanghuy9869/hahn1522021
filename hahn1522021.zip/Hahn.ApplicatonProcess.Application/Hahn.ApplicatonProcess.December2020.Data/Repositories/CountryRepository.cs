﻿using Hahn.ApplicatonProcess.December2020.Core.Interfaces;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.December2020.Data.Repositories
{
    public class CountryRepository : ICountryRepository
    {
        private readonly IHttpClientFactory _clientFactory;
        private readonly IConfiguration _configuration;

        public CountryRepository(IHttpClientFactory clientFactory, IConfiguration Configuration)
        {
            _clientFactory = clientFactory;
            _configuration = Configuration;
        }

        public async Task<bool> ValidateCountry(string countryName)
        {
            var apiUrl = this._configuration.GetValue<string>("AppSetting:ValidateCountryApi");
            var url = String.Format(apiUrl, countryName);
            var client = _clientFactory.CreateClient();
            var request = new HttpRequestMessage(HttpMethod.Get, url);
            var isValid = (await client.SendAsync(request)).IsSuccessStatusCode;
            return isValid;
        }
    }
}
