﻿using Hahn.ApplicatonProcess.December2020.Core.DomainModels;
using Hahn.ApplicatonProcess.December2020.Core.Interfaces;
using System;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.December2020.Domain.Services
{
    public class ApplicantService : IApplicantService
    {
        private readonly IApplicantRepository _applicantRepo;

        public ApplicantService(IApplicantRepository applicantRepo)
        {
            this._applicantRepo = applicantRepo;
        }

        public async Task<Applicant> AddAsync(Applicant applicant)
        {
            return await _applicantRepo.AddAsync(applicant);
        }

        public async Task<bool> IsExisted(int id)
        {
            return await _applicantRepo.AnyAsync(a => a.Id == id);
        }

        public async Task DeleteByIdAsync(int id)
        {
            await _applicantRepo.DeleteByIdAsync(id);
        }

        public async Task<Applicant> GetAsync(int id)
        {
            return await _applicantRepo.GetAsync(a => a.Id == id);
        }

        //public async Task<IEnumerable<Applicant>> SelectWhere(Expression<Func<Applicant, bool>> where)
        //{
        //    return await _dbSet.Where(where).ToListAsync();
        //}

        public async Task UpdateAsync(Applicant applicant)
        {
            await _applicantRepo.UpdateAsync(applicant);
        }
    }
}
