﻿using Hahn.ApplicatonProcess.December2020.Core.Interfaces;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.December2020.Domain.Services
{
    public class CountryService : ICountryService
    {
        private readonly ICountryRepository _countryRepo;

        public CountryService(ICountryRepository countryRepo)
        {
            _countryRepo = countryRepo;
        }

        public async Task<bool> ValidateCountry(string countryName)
        {
            return await _countryRepo.ValidateCountry(countryName);
        }
    }
}
