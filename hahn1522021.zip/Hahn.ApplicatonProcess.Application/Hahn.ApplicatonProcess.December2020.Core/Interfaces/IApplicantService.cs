﻿using Hahn.ApplicatonProcess.December2020.Core.DomainModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.December2020.Core.Interfaces
{
    public interface IApplicantService
    {
        Task<Applicant> AddAsync(Applicant applicant);
        //Task<bool> AnyAsync(Expression<Func<Applicant, bool>> where);
        Task DeleteByIdAsync(int id);
        Task<Applicant> GetAsync(int id);
        Task UpdateAsync(Applicant applicant);
        Task<bool> IsExisted(int id);
    }
}
