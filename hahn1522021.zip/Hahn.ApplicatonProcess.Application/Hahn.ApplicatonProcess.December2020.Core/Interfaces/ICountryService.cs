﻿using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.December2020.Core.Interfaces
{
    public interface ICountryService
    {
        Task<bool> ValidateCountry(string countryName);
    }
}
