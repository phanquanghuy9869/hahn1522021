﻿using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.December2020.Core.Interfaces
{
    public interface ICountryRepository
    {
        Task<bool> ValidateCountry(string countryName);
    }
}
