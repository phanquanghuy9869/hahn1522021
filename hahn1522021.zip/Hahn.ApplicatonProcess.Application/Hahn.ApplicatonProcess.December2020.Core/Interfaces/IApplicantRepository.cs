﻿using Hahn.ApplicatonProcess.December2020.Core.DomainModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.December2020.Core.Interfaces
{
    public interface IApplicantRepository : IGenericRepository<Applicant>
    {
        Task DeleteByIdAsync(int id);
    }
}
