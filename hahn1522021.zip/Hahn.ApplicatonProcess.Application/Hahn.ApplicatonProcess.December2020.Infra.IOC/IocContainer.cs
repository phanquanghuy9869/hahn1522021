﻿using Hahn.ApplicatonProcess.December2020.Core.Interfaces;
using Hahn.ApplicatonProcess.December2020.Data.AppDbContexts;
using Hahn.ApplicatonProcess.December2020.Data.Repositories;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore.InMemory;
using Microsoft.EntityFrameworkCore;
using Hahn.ApplicatonProcess.December2020.Domain.Services;

namespace Hahn.ApplicatonProcess.December2020.Infra.IOC
{
    public static class IocContainer
    {
        public static void RegisterIoc(this IServiceCollection services)
        {
            services.AddScoped<IApplicantRepository, ApplicantRepository>();
            services.AddScoped<IApplicantService, ApplicantService>();
            services.AddScoped<DbContext, AppDbContext>();
            services.AddScoped<ICountryRepository, CountryRepository>();
            services.AddScoped<ICountryService, CountryService>();
        }

        public static void RegisterDb(this IServiceCollection services)
        {
            services.AddDbContext<AppDbContext>(opt => opt.UseInMemoryDatabase(databaseName: "hahn"));
        }
    }
}
